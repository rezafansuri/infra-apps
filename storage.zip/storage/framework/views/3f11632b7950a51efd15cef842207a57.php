<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\DATA\REZA\01_APPL\Laravel\infra-app\vendor\filament\widgets\resources\views/components/widget.blade.php ENDPATH**/ ?>