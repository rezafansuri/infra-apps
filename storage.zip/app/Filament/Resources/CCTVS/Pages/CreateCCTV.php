<?php

namespace App\Filament\Resources\CCTVS\Pages;

use App\Filament\Resources\CCTVS\CCTVResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCCTV extends CreateRecord
{
    protected static string $resource = CCTVResource::class;
}
